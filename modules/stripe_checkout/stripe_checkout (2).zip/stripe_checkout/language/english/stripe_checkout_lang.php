<?php

$lang['credit_card_details']  = 'Credit Card Details';
$lang['card_number']  = 'Credit Card Number';
$lang['expire']  = 'Expire';
$lang['cvv']  = 'CVV';
$lang['card_name']  = 'Name on Card';
$lang['card_details_saved_successfully'] = 'Card Details Saved Successfully';
$lang['card_details_updated_successfully']  = 'Card Details Updated Successfully';
